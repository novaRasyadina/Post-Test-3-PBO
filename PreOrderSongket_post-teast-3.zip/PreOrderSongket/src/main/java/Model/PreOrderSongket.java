/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author TUF GAMING
 */
    public class PreOrderSongket extends PreOrder {
    private String motif;

    public PreOrderSongket(String namaPelanggan, String alamat, int jumlah, String motif) {
        super(namaPelanggan, alamat, jumlah); // panggil constructor superclass
        this.motif = motif;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    @Override
    public String toString() {
        return super.toString() + ", Jenis Kain: Songket, Motif: " + motif;
    }
}
