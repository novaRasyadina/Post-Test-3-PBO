/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author TUF GAMING
 */
// Subclass 2
public class PreOrderEksklusif extends PreOrder {
    private String bahan;

    public PreOrderEksklusif(String namaPelanggan, String alamat, int jumlah, String bahan) {
        super(namaPelanggan, alamat, jumlah);
        this.bahan = bahan;
    }

    public String getBahan() {
        return bahan;
    }

    public void setBahan(String bahan) {
        this.bahan = bahan;
    }

    @Override
    public String toString() {
        return super.toString() + ", Jenis Kain: Eksklusif, Bahan: " + bahan;
    }
}
