/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.util.ArrayList;
import java.util.Scanner;
import Model.PreOrder;
import Model.PreOrderSongket;
import Model.PreOrderEksklusif;
/**
 *
 * @author TUF GAMING
 */
public class PreOrderService {
    private final ArrayList<PreOrder> listPreOrder = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    public void tambahPreOrder() {
        System.out.print("Masukkan nama pelanggan: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan alamat: ");
        String alamat = scanner.nextLine();

        int jumlah = 0;
        while (true) {
            System.out.print("Masukkan jumlah kain: ");
            try {
                jumlah = Integer.parseInt(scanner.nextLine());
                if (jumlah <= 0) {
                    System.out.println("Jumlah harus lebih dari 0!");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid! Masukkan angka.");
            }
        }

        System.out.println("Pilih jenis kain: ");
        System.out.println("1. Songket");
        System.out.println("2. Eksklusif");
        System.out.print("Pilihan: ");
        int jenis = Integer.parseInt(scanner.nextLine());

        PreOrder po;
        if (jenis == 1) {
            System.out.print("Masukkan motif songket: ");
            String motif = scanner.nextLine();
            po = new PreOrderSongket(nama, alamat, jumlah, motif);
        } else {
            System.out.print("Masukkan bahan kain eksklusif: ");
            String bahan = scanner.nextLine();
            po = new PreOrderEksklusif(nama, alamat, jumlah, bahan);
        }

        listPreOrder.add(po);
        System.out.println("Pre-Order berhasil ditambahkan!");
    }

    public void tampilkanPreOrder() {
        if (listPreOrder.isEmpty()) {
            System.out.println("Belum ada data pre-order.");
        } else {
            System.out.println("\n=== Daftar Pre-Order ===");
            for (PreOrder po : listPreOrder) {
                System.out.println(po);
            }
        }
    }

    public void updatePreOrder() {
        System.out.print("Masukkan ID pre-order yang akan diupdate: ");
        int id = Integer.parseInt(scanner.nextLine());

        PreOrder po = cariById(id);
        if (po == null) {
            System.out.println("Data dengan ID tersebut tidak ditemukan.");
            return;
        }

        System.out.print("Masukkan nama baru (kosongkan jika tidak diubah): ");
        String nama = scanner.nextLine();
        if (!nama.isEmpty()) po.setNamaPelanggan(nama);

        System.out.print("Masukkan alamat baru (kosongkan jika tidak diubah): ");
        String alamat = scanner.nextLine();
        if (!alamat.isEmpty()) po.setAlamat(alamat);

        System.out.print("Masukkan jumlah baru (0 = tidak diubah): ");
        try {
            int jumlah = Integer.parseInt(scanner.nextLine());
            if (jumlah > 0) po.setJumlah(jumlah);
        } catch (NumberFormatException e) {
            System.out.println("Jumlah tidak valid, data lama tetap digunakan.");
        }

        System.out.println("Data berhasil diperbarui!");
    }

    public void hapusPreOrder() {
        System.out.print("Masukkan ID pre-order yang akan dihapus: ");
        int id = Integer.parseInt(scanner.nextLine());

        PreOrder po = cariById(id);
        if (po == null) {
            System.out.println("Data dengan ID tersebut tidak ditemukan.");
            return;
        }

        listPreOrder.remove(po);
        System.out.println("Data berhasil dihapus!");
    }

    public void cariPreOrder() {
        System.out.print("Masukkan nama pelanggan yang dicari: ");
        String keyword = scanner.nextLine().toLowerCase();

        boolean ditemukan = false;
        for (PreOrder po : listPreOrder) {
            if (po.getNamaPelanggan().toLowerCase().contains(keyword)) {
                System.out.println(po);
                ditemukan = true;
            }
        }
        if (!ditemukan) {
            System.out.println("Tidak ada data dengan nama tersebut.");
        }
    }

    private PreOrder cariById(int id) {
        for (PreOrder po : listPreOrder) {
            if (po.getId() == id) {
                return po;
            }
        }
        return null;
    }
}
