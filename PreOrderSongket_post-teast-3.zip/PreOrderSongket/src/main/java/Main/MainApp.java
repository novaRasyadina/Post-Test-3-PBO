/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
import java.util.Scanner;
import Service.PreOrderService;

/**
 *
 * @author TUF GAMING
 */
public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PreOrderService service = new PreOrderService();

        int pilihan;
        do {
            System.out.println("\n=== Pre-Order Kain Songket ===");
            System.out.println("1. Tambah Pre-Order");
            System.out.println("2. Tampilkan Semua Pre-Order");
            System.out.println("3. Update Pre-Order");
            System.out.println("4. Hapus Pre-Order");
            System.out.println("5. Cari Pre-Order");
            System.out.println("6. Keluar");
            System.out.print("Pilih menu: ");

            try {
                pilihan = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid! Harus angka.");
                pilihan = -1;
            }

            switch (pilihan) {
                case 1 -> service.tambahPreOrder();
                case 2 -> service.tampilkanPreOrder();
                case 3 -> service.updatePreOrder();
                case 4 -> service.hapusPreOrder();
                case 5 -> service.cariPreOrder();
                case 6 -> System.out.println("Terima kasih telah menggunakan program ini!");
                default -> System.out.println("Pilihan tidak valid!");
            }
        } while (pilihan != 6);

        scanner.close();
    }
}
